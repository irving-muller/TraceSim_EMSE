import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.index.Term;
import org.apache.lucene.search.BooleanClause;
import org.apache.lucene.search.BooleanQuery;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.TermQuery;

import java.util.List;

public class BagOfWordsQueryGenerator extends QueryGenerator {
    @Override
    public Query buildQuery(String field, Analyzer analyzer, String queryText) {
        List<String> tokens = AnalyzerUtils.analyze(analyzer, queryText);

        BooleanQuery.Builder builder = new BooleanQuery.Builder();
        for (String t : tokens) {
            builder.add(new TermQuery(new Term(field, t)), BooleanClause.Occur.SHOULD);
        }

        return builder.build();
    }
}