import org.apache.lucene.index.DirectoryReader;
import org.apache.lucene.search.ScoreDoc;
import org.apache.lucene.search.TopDocs;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import java.io.DataOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.*;


public class ResultCollectionSparse implements ResultCollection {
    private DataOutputStream outputStream;
    private HashMap<Long, Long> report2master;
    private int window;
    private int topN;

    public ResultCollectionSparse(JSONArray reports, String path, int numQueries, int topN) throws IOException {
        this.window = window > 0 ? window : -1;
        this.report2master = new HashMap<>();
        this.topN = topN;

        for (Object o : reports) {
            JSONObject r = (JSONObject) o;
            Long bug_id = (Long) r.get("bug_id");
            Long dup_id = (Long) r.get("dup_id");

            if (dup_id == null)
                dup_id = bug_id;

            this.report2master.put(bug_id, dup_id);
        }

        File f = new File(path);
        f.createNewFile();

        this.outputStream = new DataOutputStream(new FileOutputStream(f));
        this.outputStream.writeInt(numQueries);
        this.outputStream.writeInt(topN);
    }

    public void add(long queryId, TopDocs docs, DirectoryReader directoryReader, HashSet<Long> candidateSet) throws IOException {
        Long qMasterId = this.report2master.get(queryId);

        this.outputStream.writeLong(queryId);

        if (docs != null) {
            boolean isDup = qMasterId != queryId;
            boolean hasFound = false;
            List<Tuple> reports = new LinkedList<>();


//            List<Long> all = new ArrayList<>();
//            for (ScoreDoc scoreDoc :
//                    docs.scoreDocs) {
//                all.add(Long.parseLong(directoryReader.document(scoreDoc.doc).getField("bug_id").stringValue()));
//            }
//            Collections.sort(all);
//            System.out.println(all);

            for (ScoreDoc scoreDoc :
                    docs.scoreDocs) {
                Long cand_id = Long.parseLong(directoryReader.document(scoreDoc.doc).getField("bug_id").stringValue());


                if (!candidateSet.contains(cand_id))
                    continue;

                reports.add(new Tuple(cand_id, (double) scoreDoc.score));

                if (isDup) {
                    if (this.report2master.get(cand_id).equals(qMasterId))
                        hasFound = true;

                    if (hasFound && reports.size() >= this.topN) {
                        break;
                    }
                } else {
                    if (reports.size() >= this.topN)
                        break;
                }
            }
            //Fix
            this.outputStream.writeInt(reports.size());

//            List<Long> a = new ArrayList<>();
//            List<Double> b = new ArrayList<>();

            for (Tuple t :
                    reports) {
                this.outputStream.writeLong(t.repId);
                this.outputStream.writeDouble(t.score);
//                a.add(t.repId);
//                b.add(t.score);
            }

//            System.out.print(queryId);
//            System.out.print(" ");
//            System.out.print(a);
//            System.out.print(" ");
//            System.out.print(b);
//            System.out.println();
        } else {
            this.outputStream.writeInt(0);
        }
    }

    public void close() throws IOException {
        this.outputStream.close();
    }
}
