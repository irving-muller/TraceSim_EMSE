
import org.apache.commons.lang3.StringUtils;
import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.TokenStream;
import org.apache.lucene.analysis.tokenattributes.CharTermAttribute;
import org.apache.lucene.document.Document;
import org.apache.lucene.index.IndexableField;

import java.io.IOException;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class AnalyzerUtils {

    static public List<String> analyze(Analyzer analyzer, String s) {
        return analyze(analyzer, s, null);
    }

    static public List<String> analyze(Analyzer analyzer, String s, String fieldName) {
        List<String> list = new ArrayList<>();

        try {
            TokenStream tokenStream = analyzer.tokenStream(fieldName, new StringReader(s));
            CharTermAttribute cattr = tokenStream.addAttribute(CharTermAttribute.class);
            tokenStream.reset();
            while (tokenStream.incrementToken()) {
                if (cattr.toString().length() == 0) {
                    continue;
                }
                list.add(cattr.toString());
            }
            tokenStream.end();
            tokenStream.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

        return list;
    }


    static public Map<String, String> analyse(Analyzer analyzer, Document doc) {
        Map<String, String> d = new HashMap<>();

        try {
            for (IndexableField field :
                    doc.getFields()) {
                List<String> list = new ArrayList<>();
                if (field.name().equals("bug_id"))
                    continue;

                if (field.stringValue().length() > 0) {
                    TokenStream tokenStream = analyzer.tokenStream(field.name(), field.stringValue());
                    CharTermAttribute cattr = tokenStream.addAttribute(CharTermAttribute.class);
                    tokenStream.reset();
                    while (tokenStream.incrementToken()) {
                        if (cattr.toString().length() == 0) {
                            continue;
                        }
                        list.add(cattr.toString());
                    }
                    tokenStream.end();
                    tokenStream.close();
                }

                d.put(field.name(), StringUtils.join(list, ' '));
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return d;
    }

}