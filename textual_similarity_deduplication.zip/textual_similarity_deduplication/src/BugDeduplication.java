import filter.Filter;
import filter.FilterFactory;
import net.sourceforge.argparse4j.ArgumentParsers;
import net.sourceforge.argparse4j.impl.Arguments;
import net.sourceforge.argparse4j.inf.ArgumentParser;
import net.sourceforge.argparse4j.inf.Namespace;
import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.CharArraySet;
import org.apache.lucene.analysis.en.EnglishAnalyzer;
import org.apache.lucene.analysis.miscellaneous.PerFieldAnalyzerWrapper;
import org.apache.lucene.document.Document;
import org.apache.lucene.index.*;
import org.apache.lucene.search.*;
import org.apache.lucene.search.similarities.BM25Similarity;
import org.apache.lucene.search.similarities.ClassicSimilarity;
import org.apache.lucene.search.similarities.Similarity;
import org.apache.lucene.store.FSDirectory;
import org.apache.lucene.store.MMapDirectory;
import org.apache.lucene.store.NIOFSDirectory;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import java.io.FileReader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.InvalidParameterException;
import java.util.*;


public class BugDeduplication {

    public static void addOpt(JSONArray json, List<String> l) {
        for (Object o :
                json) {
            l.add((String) o);
        }
    }

    public static DefaultEnglishAnalyzer buildAnalyzer(JSONObject analyzerConfig) {
        String filter = (String) analyzerConfig.get("filter");
        Boolean stopWords = (Boolean) analyzerConfig.get("stop_words");
        String stemmer = (String) analyzerConfig.get("stemmer");
        String tokenizer = (String) analyzerConfig.get("tokenizer");
        CharArraySet stopWordSet = stopWords ? EnglishAnalyzer.ENGLISH_STOP_WORDS_SET : CharArraySet.EMPTY_SET;
        JSONArray nGramConfig = (JSONArray) analyzerConfig.get("n_gram");
        int[] nGram = null;

        if (nGramConfig != null) {
            int minNGram, maxNGram;

            if (nGramConfig.size() == 1) {
                minNGram = 2;
                maxNGram = ((Long) nGramConfig.get(0)).intValue();
            } else {
                minNGram = ((Long) nGramConfig.get(0)).intValue();
                maxNGram = ((Long) nGramConfig.get(1)).intValue();
            }

            nGram = new int[]{minNGram, maxNGram};
        }

        return new DefaultEnglishAnalyzer(tokenizer, stemmer, stopWordSet, filter, nGram);
    }

    public static void main(String[] args) {
        ArgumentParser argsParser = ArgumentParsers.newFor("Checksum").build()
                .defaultHelp(true)
                .description("Calculate checksum of given files.");
        argsParser.addArgument("-db").required(true);
        argsParser.addArgument("-training").nargs("*").required(false);
        argsParser.addArgument("-validation").required(true);
        argsParser.addArgument("-index").required(true);
        argsParser.addArgument("-out").required(true);
        argsParser.addArgument("-config").required(true);
        argsParser.addArgument("-keep").action(Arguments.storeTrue());
        argsParser.addArgument("-k1");
        argsParser.addArgument("-b");
        argsParser.addArgument("-sparse").action(Arguments.storeTrue());
        argsParser.addArgument("-min_top_score").type(Integer.class).setDefault(50);
        argsParser.addArgument("-window").type(Integer.class).setDefault(-1);

        JSONParser parser = new JSONParser();

        try {
            Namespace res = argsParser.parseArgs(args);
            System.out.println(res.toString());

            if (Files.exists(Paths.get(res.getString("out")))) {
                System.err.println("Output File " + res.getString("out") + " exists!");
                System.exit(-1);
            }

            // Load database
            JSONArray reports = (JSONArray) parser.parse(new FileReader(res.getString("db")));

            // Read configurations
            JSONObject config = (JSONObject) parser.parse(new FileReader((String) res.get("config")));

            System.out.println(config.toJSONString().replace("\n", " "));
            Boolean joinNestedMain = (Boolean) config.getOrDefault("join_nested_main", false);

            // Set black list, white list and no index list
            JSONObject fieldConfig = (JSONObject) config.get("fields");

            List<String> noIndexFields = new ArrayList<>(List.of("bug_id", "dup_id"));
            List<String> noParseFields = new ArrayList<>();
            List<String> blackListFields = new ArrayList<>(List.of("dup_id", "date", "database_id", "creation_ts", "stacktrace\\.frames\\.depth"));
            List<String> whiteListFields = new ArrayList<>(List.of("bug_id"));

            addOpt((JSONArray) fieldConfig.getOrDefault("no_index_list", new JSONArray()), noIndexFields);
            addOpt((JSONArray) fieldConfig.getOrDefault("no_parse_list", new JSONArray()), noParseFields);
            addOpt((JSONArray) fieldConfig.getOrDefault("black_list", new JSONArray()), blackListFields);
            addOpt((JSONArray) fieldConfig.getOrDefault("white_list", new JSONArray()), whiteListFields);

            System.out.println("no_index_list: " + noIndexFields.toString());
            System.out.println("no_parse_list: " + noParseFields.toString());
            System.out.println("black_list: " + blackListFields.toString());
            System.out.println("white_list: " + whiteListFields.toString());


            // Set env
            DocumentGenerator documentGenerator = new DocumentGenerator(blackListFields, noIndexFields, whiteListFields, noParseFields);

            String fsDirectoryType = (String) config.get("fs_directory");
            Path tempDir = Files.createTempDirectory(Paths.get(res.getString("index")), "index");
            FSDirectory directory;

            if (fsDirectoryType == null || fsDirectoryType.equals("mmap")) {
                directory = new MMapDirectory(tempDir);
            } else if (fsDirectoryType.equals("niofs")) {
                directory = new NIOFSDirectory(tempDir);
            } else {
                directory = new MMapDirectory(tempDir);
            }

            // Set similarity
            Similarity similarity;
            JSONObject sim_conf = (JSONObject) config.get("similarity");

            if (sim_conf.get("method").equals("bm25")) {
                float k1 = ((Double) sim_conf.getOrDefault("k1", 1.2)).floatValue();
                float b = ((Double) sim_conf.getOrDefault("b", 0.75)).floatValue();

                if (res.get("k1") != null)
                    k1 = Float.valueOf(res.get("k1"));

                if (res.get("b") != null)
                    b = Float.valueOf(res.get("b"));

                System.out.println("BM25" + " k1=" + String.valueOf(k1) + " b=" + String.valueOf(b));
                similarity = new BM25Similarity(k1, b);
            } else if (sim_conf.get("method").equals("tf_idf")) {
                System.out.println("TF-IDF");
                similarity = new ClassicSimilarity();
            } else {
                throw new InvalidParameterException("sim config " + sim_conf.get("method") + " is invalid");
            }

            // Preprocessing
            Map<String, List<Filter>> preprocessing = new HashMap<>();
            JSONObject preprocessingJson = (JSONObject) config.getOrDefault("preprocessing", new JSONObject());
            Iterator iter = preprocessingJson.entrySet().iterator();


            while (iter.hasNext()) {
                Map.Entry e = (Map.Entry) iter.next();
                String field = (String) e.getKey();
                List<Filter> filters = preprocessing.getOrDefault(field, new ArrayList<Filter>());

                if (filters.isEmpty()) {
                    preprocessing.put(field, filters);
                }

                JSONArray filtersJson = (JSONArray) e.getValue();

                for (Object o :
                        filtersJson) {
                    Filter f = FilterFactory.factory((JSONArray) o);
                    FilterFactory.test(f);
                    filters.add(f);
                }
            }

            // Set analyzer
            JSONObject analyzerConfig = (JSONObject) config.get("def_analyzer");
            DefaultEnglishAnalyzer defaultAnalyzer = buildAnalyzer(analyzerConfig);
            JSONArray fieldAnalyserConfig = (JSONArray) config.get("analyser_per_field");

            Analyzer analyzer;
            Map<String, Analyzer> field2analyzer = new HashMap<>();

            if (fieldAnalyserConfig != null) {
                for (int i = 0; i < fieldAnalyserConfig.size(); i++) {
                    JSONObject fc = (JSONObject) fieldAnalyserConfig.get(i);
                    JSONArray fields = (JSONArray) fc.get("fields");
                    DefaultEnglishAnalyzer fieldAnalyzer = buildAnalyzer((JSONObject) fc.get("analyzer"));

                    for (int j = 0; j < fields.size(); j++) {
                        if (field2analyzer.put((String) fields.get(j), fieldAnalyzer) != null) {
                            throw new Exception("Multiple analyzer to the field " + fields.get(j));
                        }
                    }
                }

                analyzer = new PerFieldAnalyzerWrapper(defaultAnalyzer, field2analyzer);
            } else {
                analyzer = defaultAnalyzer;
            }

            String testString = "org.eclipse.vcm.internal.core.ccvs.client.Client.execute MooseX::FTPClass2_beta XRef::getEntry(int) PDFDoc::PDFDoc(GooString*, GooString*, GooString*, void*) 0x00555bae isString 0x00002b344498a150 in CairoOutputDev::setDefaultCTM () from /usr/lib/libpoppler-glib.so.1";
            System.out.println("Test Analyzer:\n\tinput: " + testString + "\n\toutput: " + AnalyzerUtils.analyze(analyzer, testString, null));

            for (String e : field2analyzer.keySet()) {
                System.out.println("FIELD " + e + "\tTest Analyzer:\n\tinput: " + testString + "\n\toutput: " + AnalyzerUtils.analyze(analyzer, testString, e));
            }


            IndexWriterConfig writerConfig = new IndexWriterConfig(analyzer);


            if (res.getBoolean("keep")) {
                writerConfig.setOpenMode(IndexWriterConfig.OpenMode.CREATE_OR_APPEND);
            } else {
                writerConfig.setOpenMode(IndexWriterConfig.OpenMode.CREATE);
            }

            IndexWriter indexWriter = new IndexWriter(directory, writerConfig);

            List<String> training_list = res.getList("training");

            long start = System.currentTimeMillis();
            long end;
            int window = res.getInt("window");
            ReportFilter reportFilter = new ReportFilter(window);

            Map<Long,Report> id2report = new HashMap<>(100000);
            JSONObject jsonReport;
            Report r;

            for (Object obj :
                    reports) {
                jsonReport = (JSONObject) obj;
                r = new Report(jsonReport, preprocessing, joinNestedMain);

                id2report.put(r.getId(), r);
            }

            if (training_list != null) {
                List<Document> trainingDocuments = new LinkedList<>();

                for (String training_path: training_list) {
                    ReportDataset training = new ReportDataset(training_path);
                    System.out.println(String.format("Storing reports from training: %s", training_path));

                    for (long reportId :
                            training.getReportIds()) {
                        Report report = id2report.remove(reportId);
                        Document report_doc = documentGenerator.generateAndUpdate(report);
                        trainingDocuments.add(report_doc);

                        reportFilter.add(report);
                    }
                }
                System.out.println(String.format("Example of document:\n\t%s", AnalyzerUtils.analyse(analyzer, trainingDocuments.get(1))));
                end = System.currentTimeMillis();
                System.out.println(String.format("Duration to store training reports %d: %f", trainingDocuments.size(), (end - start) / 1000.0));


                indexWriter.addDocuments(trainingDocuments);
            }

            ReportDataset validation = new ReportDataset(res.getString("validation"));
            Map<String, Float> fieldBoosts = new HashMap<>();

            DirectoryReader directoryReader;

            BooleanQuery.setMaxClauseCount(Integer.MAX_VALUE);
            long[] validationReportIds = validation.getReportIds();

            Boolean sparse = res.getBoolean("sparse");

            ResultCollection resultCollections;
            int minTopScore = res.getInt("min_top_score");

            if (sparse) {
                resultCollections = new ResultCollectionSparse(reports, res.getString("out"), validationReportIds.length, minTopScore);
            } else {
                resultCollections = new ResultCollectionDense(res.getString("out"), validationReportIds.length);
            }

            System.out.println("Generate recommendation list for validation");
            start = System.currentTimeMillis();

            long startValidation = System.currentTimeMillis();
            int n_ignored_queries = 0;

            for (int i = 0; i < validationReportIds.length; i++) {
                if (i > 0 && i % 500 == 0) {
                    end = System.currentTimeMillis();
                    System.out.println(String.format("Number of queries %d in %f. Nm of ignored: %d", i - n_ignored_queries, (end - start) / 1000.0, n_ignored_queries));
                    start = System.currentTimeMillis();
                }

                long reportId = validationReportIds[i];

                //  Report_doc must be generated before creating the query
                Report report = id2report.remove(reportId);
                Document report_doc = documentGenerator.generateAndUpdate(report);

                // update directory reader
                directoryReader = DirectoryReader.open(indexWriter);
                HashSet<Long> candidateList = new HashSet<>(reportFilter.getCandidates(report));

                if (candidateList.size() > 0 && report.getLabel() ) {
                    // Search for similar documents
                    IndexSearcher searcher = new IndexSearcher(directoryReader);
                    searcher.setSimilarity(similarity);

                    Query query = QueryGenerator.createQuery(report, fieldBoosts, analyzer);

                    TopScoreDocCollector collector = TopScoreDocCollector.create(directoryReader.numDocs(), Integer.MAX_VALUE);
                    searcher.search(query, collector);
                    resultCollections.add(reportId, collector.topDocs(), directoryReader, candidateList);
                } else {
                    if (!report.getLabel())
                        n_ignored_queries+=1;
                    resultCollections.add(reportId, null, directoryReader, candidateList);
                }

                // Store report
                indexWriter.addDocument(report_doc);

                if (reportFilter != null)
                    reportFilter.add(report);

                if (i > 0 && i % 2000 == 0)
                    indexWriter.flush();
            }

            end = System.currentTimeMillis();
            System.out.println(String.format("Duration to generate recommendation list for %d: %f", validationReportIds.length, (end - startValidation) / 1000.0));

            // Store results
            resultCollections.close();
            System.out.println("Done");

//            //      Calculate metrics
            JSONObject pythonConf = (JSONObject) config.get("python");

//            if (pythonConf != null) {
//                String filePath = (String) pythonConf.get("script");
//                String thresholds = StringUtils.join((JSONArray) pythonConf.getOrDefault("t", new JSONArray()), " ");
//                String t = thresholds.length() > 0 ? "-t " + thresholds : "";
//                String command = String.format("python %s %s %s %s -add_cand -result_file %s", filePath, res.getString("db"), res.getString("validation"), t, res.getString("out"));
//                System.out.println(command);
//                File folder = new File((String) pythonConf.get("dir"));
//                Process p = Runtime.getRuntime().exec(command, null, folder);
//                BufferedReader stdInput = new BufferedReader(new InputStreamReader(p.getInputStream()));
//                BufferedReader stdError = new BufferedReader(new InputStreamReader(p.getErrorStream()));
//
//                System.out.println("\n################Result################\n");
//                String line;
//                while ((line = stdInput.readLine()) != null) {
//                    System.out.println(line);
//                }
//
//                while ((line = stdError.readLine()) != null) {
//                    System.out.println(line);
//                }
//
//            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }
}
