import org.apache.lucene.analysis.*;
import org.apache.lucene.analysis.core.LetterTokenizer;
import org.apache.lucene.analysis.core.WhitespaceTokenizer;
import org.apache.lucene.analysis.en.EnglishAnalyzer;
import org.apache.lucene.analysis.en.EnglishPossessiveFilter;
import org.apache.lucene.analysis.en.KStemFilter;
import org.apache.lucene.analysis.en.PorterStemFilter;
import org.apache.lucene.analysis.miscellaneous.SetKeywordMarkerFilter;
import org.apache.lucene.analysis.miscellaneous.WordDelimiterGraphFilterFactory;
import org.apache.lucene.analysis.pattern.PatternTokenizer;
import org.apache.lucene.analysis.shingle.ShingleFilter;
import org.apache.lucene.analysis.standard.StandardTokenizer;

import java.security.InvalidParameterException;
import java.util.HashMap;
import java.util.regex.Pattern;

interface FilterPipeline {
    TokenStream apply(TokenStream result, CharArraySet stopWords);
}

class Standard implements FilterPipeline {

    @Override
    public TokenStream apply(TokenStream result, CharArraySet stopWords) {
        result = new EnglishPossessiveFilter(result);
        result = new LowerCaseFilter(result);
        return new StopFilter(result, stopWords);
    }
}

class Lower implements FilterPipeline {

    @Override
    public TokenStream apply(TokenStream result, CharArraySet stopWords) {
        return new LowerCaseFilter(result);
    }
}


class NoneFilter implements FilterPipeline {

    @Override
    public TokenStream apply(TokenStream result, CharArraySet stopWords) {
        return result;
    }
}


class LowerCamelCase implements FilterPipeline {
    WordDelimiterGraphFilterFactory factory;

    public LowerCamelCase() {
        HashMap<String, String> m = new HashMap<>();
        factory = new WordDelimiterGraphFilterFactory(m);
    }

    @Override
    public TokenStream apply(TokenStream result, CharArraySet stopWords) {
        result = factory.create(result);
        return new LowerCaseFilter(result);
    }
}


class StandardCamelCase implements FilterPipeline {

    WordDelimiterGraphFilterFactory factory;

    public StandardCamelCase() {
        HashMap<String, String> m = new HashMap<>();
        factory = new WordDelimiterGraphFilterFactory(m);
    }

    @Override
    public TokenStream apply(TokenStream result, CharArraySet stopWords) {
        result = new EnglishPossessiveFilter(result);
        result = factory.create(result);
        result = new LowerCaseFilter(result);

        return new StopFilter(result, stopWords);
    }
}

public class DefaultEnglishAnalyzer extends StopwordAnalyzerBase {
    private final boolean stem;
    private final String stemmer;
    private final String tokenizer;
    private final FilterPipeline filterPipeline;
    private final CharArraySet stemExclusionSet = CharArraySet.EMPTY_SET;
    private final int[] nGram;

    // Constructors are private - use static factory methods to construct.
    public DefaultEnglishAnalyzer(String tokenizer, String stemmer, CharArraySet stopwords, String filter_config, int[] nGram) {
        super(stopwords);
        this.stem = stemmer != null;
        this.stemmer = stemmer;
        this.tokenizer = tokenizer;
        this.nGram = nGram;

        switch (filter_config) {
            case "std_camel_case":
                filterPipeline = new StandardCamelCase();
                break;
            case "lower_camel_case":
                filterPipeline = new LowerCamelCase();
                break;
            case "lower":
                filterPipeline = new Lower();
                break;
            case "std":
                filterPipeline = new Standard();
                break;
            case "none":
                filterPipeline = new NoneFilter();
                break;
            default:
                throw new InvalidParameterException("filter config " + filter_config + " is invalid");
        }
    }

    protected TokenStreamComponents createComponents(String fieldName) {
        Tokenizer source;
        TokenStream result;

        switch (tokenizer) {
            case "whitespace":
                source = new WhitespaceTokenizer(350);
                break;
            case "camel_case":
//             https://github.com/elastic/elasticsearch/blob/1.6/docs/reference/analysis/analyzers/pattern-analyzer.asciidoc
                Pattern pattern = Pattern.compile("([^\\p{L}\\d]+)|(?<=\\D)(?=\\d)|(?<=\\d)(?=\\D)|(?<=[\\p{L}&&[^\\p{Lu}]])(?=\\p{Lu})|(?<=\\p{Lu})(?=\\p{Lu}[\\p{L}&&[^\\p{Lu}]])");
                source = new PatternTokenizer(pattern, -1);
                break;
            case "std":
                source = new StandardTokenizer();
                break;
            case "letter":
                source = new LetterTokenizer();
                break;
            case "punk":
                String a = "[\\W_]";
                source = new PatternTokenizer(Pattern.compile(a),-1);
                break;
            default:
                throw new InvalidParameterException("filter config " + tokenizer + " is invalid");
        }

        result = source;
        result = filterPipeline.apply(result, this.stopwords);

        if (!this.stemExclusionSet.isEmpty()) {
            result = new SetKeywordMarkerFilter(result, this.stemExclusionSet);
        }

        if (stem) {
            if (this.stemmer.compareToIgnoreCase("porter") == 0 ||
                    this.stemmer.compareToIgnoreCase("p") == 0) {
                result = new PorterStemFilter(result);
            } else if (this.stemmer.compareToIgnoreCase("krovetz") == 0 ||
                    this.stemmer.compareToIgnoreCase("k") == 0) {
                result = new KStemFilter(result);
            }
        }

        if (this.nGram != null && this.nGram.length > 0) {
            if (this.nGram.length == 1)
                result = new ShingleFilter(result, this.nGram[0]);
            else
                result = new ShingleFilter(result, this.nGram[0], this.nGram[1]);
        }

        return new TokenStreamComponents(source, result);
    }

    protected TokenStream normalize(String fieldName, TokenStream in) {
        TokenStream result = in;
        result = new LowerCaseFilter(result);
        return result;
    }

    /**
     * Creates a new instance with all defaults: Porter stemming, Lucene's default stopwords.
     *
     * @return analyzer as configured
     */
    public static final DefaultEnglishAnalyzer newDefaultInstance() {
        return new DefaultEnglishAnalyzer("standard", null, EnglishAnalyzer.ENGLISH_STOP_WORDS_SET, null, null);
    }


}