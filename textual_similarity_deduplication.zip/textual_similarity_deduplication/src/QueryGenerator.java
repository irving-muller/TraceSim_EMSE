import org.apache.commons.lang3.NotImplementedException;
import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.document.LongPoint;
import org.apache.lucene.document.StoredField;
import org.apache.lucene.document.TextField;
import org.apache.lucene.search.*;

import java.io.IOException;
import java.util.List;
import java.util.Map;


public abstract class QueryGenerator {
    public abstract Query buildQuery(String field, Analyzer analyzer, String queryText);


    static public Query createQuery(Report r, Map<String, Float> fields, Analyzer analyzer) throws IOException {
        BooleanQuery.Builder queryBuilder = new BooleanQuery.Builder();

        String fieldName;
        Class indexType;

        for (FieldIndexType e : r.getFieldIndexType()) {
            fieldName = e.getFieldName();
            indexType = e.getIndexType();

            Query queryField;

            if (indexType == TextField.class || indexType== String.class){
                queryField = new BagOfWordsQueryGenerator().buildQuery(fieldName, analyzer, r.getContent(fieldName));
            }else if(indexType == StoredField.class){
                continue;
            } else{
                throw new NotImplementedException("");
            }

            Float boost = fields.get(fieldName);

            if (boost != null) {
                queryField = new BoostQuery(queryField, boost);
            }

            queryBuilder.add(queryField, BooleanClause.Occur.SHOULD);
        }

//
//        BooleanQuery.Builder filter = new BooleanQuery.Builder();
//
//        for (Long repId : candidateList) {
//            filter.add(LongPoint.newExactQuery("bug_id", repId), BooleanClause.Occur.SHOULD);
//        }
//
//        queryBuilder.add(filter.build(), BooleanClause.Occur.FILTER);


        return queryBuilder.build();
    }
}