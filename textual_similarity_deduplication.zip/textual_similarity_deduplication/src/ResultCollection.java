import org.apache.lucene.index.DirectoryReader;
import org.apache.lucene.search.TopDocs;

import java.io.IOException;
import java.util.HashSet;

class Tuple {
    Long repId;
    Double score;

    public Tuple(Long repId, Double score) {
        this.repId = repId;
        this.score = score;
    }
}


public interface ResultCollection {
    public void add(long queryId, TopDocs docs, DirectoryReader directoryReader, HashSet<Long> candidateSet) throws IOException;
    public void close() throws IOException;
}
