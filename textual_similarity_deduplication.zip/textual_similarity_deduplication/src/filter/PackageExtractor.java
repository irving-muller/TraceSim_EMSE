package filter;

public class PackageExtractor implements Filter {
    private String undef;

    public PackageExtractor(String rep){
        undef = rep;
    }

    @Override
    public String filter(String txt) {
        int funcIdx = txt.lastIndexOf('.');

        if (funcIdx == -1)
            return this.undef;

        int classIdx = txt.lastIndexOf('.', funcIdx - 1);

        if (classIdx == -1)
            return this.undef;

        String packageName = txt.substring(0, classIdx);

        if (packageName.isEmpty())
            return this.undef;

        return packageName;
    }
}
