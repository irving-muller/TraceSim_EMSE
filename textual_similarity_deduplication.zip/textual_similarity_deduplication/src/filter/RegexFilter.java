package filter;

import java.nio.file.attribute.UserPrincipalLookupService;
import java.util.regex.Pattern;

public class RegexFilter implements Filter{
    private Pattern pattern;
    private String replace;

    public RegexFilter(String pattern){
        this.pattern = Pattern.compile(pattern);
        this.replace = "";
    }

    public RegexFilter(String pattern, String replace) {
        this.pattern = Pattern.compile(pattern);
        this.replace = replace;
    }

    @Override
    public String filter(String txt) {
        return pattern.matcher(txt).replaceAll(this.replace);
    }

    @Override
    public String toString() {
        return "RegexFilter{" +
                "pattern=" + pattern +
                ", replace='" + replace + '\'' +
                '}';
    }
}
