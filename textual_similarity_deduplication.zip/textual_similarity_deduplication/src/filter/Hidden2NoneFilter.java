package filter;

import java.util.regex.Pattern;

public class Hidden2NoneFilter implements Filter{
    private Pattern pattern;

    public Hidden2NoneFilter(String pattern){
        this.pattern = Pattern.compile(pattern);
    }

    @Override
    public String filter(String txt) {
        return pattern.matcher(txt).matches()? null : txt;
    }
}
