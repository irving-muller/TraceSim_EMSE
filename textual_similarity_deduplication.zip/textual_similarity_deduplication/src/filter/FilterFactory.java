package filter;

import java.security.InvalidParameterException;
import java.util.ArrayList;

public class FilterFactory {
    public static Filter factory(ArrayList<String> args) {
        String opt = args.get(0);
        if (opt.equals("re")) {
            String rep = args.size() == 2 ? "" : args.get(2);
            return new RegexFilter(args.get(1), rep);
        } else if (opt.equals("hidden2none")) {
            return new Hidden2NoneFilter(args.get(1));
        } else if (opt.equals("ext_package")) {
            String undef = args.size() == 1 ? null : args.get(1);
            return new PackageExtractor(undef);
        } else {
            throw new InvalidParameterException("Filter factory " + opt + " is invalid");
        }
    }

    public static void test(Filter filter) {
        // Test filters
        String[] filterTest = {"__libc_start_main", "gnash::ActionExec::operator()()", "__GI___wcscoll_l", "org.eclipse.swt.custom.BusyIndicator.showWhile", "HIDDEN.HIDDEN", "org.eclipse.core.runtime.SafeRunner.run", " space space    "};
        boolean noMatches = true;

        System.out.println(String.format("Using %s", filter.toString()));

        for (int i = 0; i < filterTest.length; i++) {
            String out = filter.filter(filterTest[i]);

            if (out == null) {
                noMatches = false;
                System.out.println(String.format("\t%s => null", filterTest[i], out));
            } else if (!out.equals(filterTest[i])) {
                noMatches = false;
                System.out.println(String.format("\t%s => %s", filterTest[i], out));
            }
        }

        if (noMatches) {
            System.out.println("\tWarning: no matches!");
        }

    }
}
