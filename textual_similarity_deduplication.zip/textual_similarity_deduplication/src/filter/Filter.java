package filter;

public interface Filter {
    String filter(String txt);
}
