import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.List;

public class ReportDataset {

    private String info;
    private long [] reportIds;


    private long [] duplicateIds;

    public ReportDataset(String path) throws IOException {
        BufferedReader reader = new BufferedReader(new FileReader(path));

        info = reader.readLine();
        String [] ids = reader.readLine().strip().split("\\s");

        reportIds = new long[ids.length];

        for (int i = 0; i < ids.length; i++) {
            reportIds[i] = Long.parseLong(ids[i]);
        }

        String line = reader.readLine().strip();

        if (line.length() > 0) {
            String [] duplicateIds = line.split("\\s");
            this.duplicateIds = new long[duplicateIds.length];

            for (int i = 0; i < duplicateIds.length; i++) {
                this.duplicateIds[i] = Long.parseLong(duplicateIds[i]);
            }
        }else{
            this.duplicateIds = new long[0];
        }

    }


    public String getInfo() {
        return info;
    }

    public long[] getReportIds() {
        return reportIds;
    }

    public long[] getDuplicateIds() {
        return duplicateIds;
    }
}
