import filter.Filter;
import org.apache.commons.lang3.StringUtils;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import java.util.*;
import java.util.regex.Pattern;


class FieldIndexType{
    private String fieldName;
    private Class indexType;

    public FieldIndexType(String fieldName, Class indexType) {
        this.fieldName = fieldName;
        this.indexType = indexType;
    }

    public String getFieldName() {
        return fieldName;
    }

    public Class getIndexType() {
        return indexType;
    }
}


public class Report {
    private HashMap<String, String> name2content;
    private Map<String, List<Filter>> field2filter;
    private boolean joinMainNested;
    private List<FieldIndexType> fieldIndexType;


    private Long id;
    private Long creationDate;
    private Long dupId;
    private Boolean label;

//    public Report(JSONObject object, Map<String, List<Filter>> filter){
//        name2content = denormalize(object, filter);
//        this.field2filter = filter;
//        this.joinMainNested = false;
//    }

    public Long getId() {
        return id;
    }

    public Long getCreationDate() {
        return creationDate;
    }

    public Long getDupId() {
        return dupId;
    }

    public Boolean getLabel() {
        return label;
    }

    public Report(JSONObject object, Map<String, List<Filter>> filter, boolean joinMainNested) {
        this.id = (Long) object.get("bug_id");
        this.dupId = object.get("dup_id") != null ? (Long) object.get("dup_id") : null;
        this.label = object.get("label") != null ? (Boolean) object.get("label") : true;
        this.fieldIndexType = null;

        Object o = object.get("creation_ts");
        Class c = o.getClass();

        if(c == Long.class){
            this.creationDate = (Long) o;
        }else if(c == Double.class){
            this.creationDate = ((Double) o).longValue();
        }

        name2content = denormalize(object, filter);

        if (joinMainNested) {
            Pattern p = Pattern.compile("stacktrace\\.nested\\.");
            Set<String> keys = new HashSet<>(name2content.keySet());
            for (String name : keys) {
                String v = p.matcher(name).replaceAll("stacktrace.");

                if (!v.equals(name)) {
                    String nestedContent = name2content.remove(name);
                    if (!nestedContent.isEmpty()) {
                        String mainContent = name2content.get(v);

                        if(mainContent == null) {
                            name2content.put(v, nestedContent);
                        }else if (mainContent.isEmpty()) {
                            name2content.replace(v, nestedContent);
                        }else{
                            name2content.replace(v, mainContent + ' ' + nestedContent);
                        }
                    }
                }
            }

        }

        this.field2filter = filter;
        this.joinMainNested = joinMainNested;
        this.fieldIndexType = null;


    }

    public List<FieldIndexType> getFieldIndexType(){
        return this.fieldIndexType;
    }

    public void addIndexType(String fieldName, Class indexType){
        if(this.fieldIndexType == null)
            this.fieldIndexType = new LinkedList<>();

        this.fieldIndexType.add(new FieldIndexType(fieldName, indexType));
    }

    public java.util.Set<String> getFieldNames() {
        return name2content.keySet();
    }

    public String getContent(String fieldName) {
        return name2content.get(fieldName);
    }

    public Set<Map.Entry<String, String>> getNameContent() {
        return name2content.entrySet();
    }

    static private void flattenJson(HashMap<String, ArrayList<String>> key2value, String key, Object value) {
        if (value instanceof JSONObject) {
            JSONObject obj = (JSONObject) value;
            for (Object n :
                    obj.keySet()) {
                String newKey = (String) n;
                newKey = key.length() > 0 ? key + "." + newKey : newKey;
                flattenJson(key2value, newKey, obj.get(n));
            }
        } else if (value instanceof JSONArray) {
            JSONArray l = (JSONArray) value;
            for (Object n :
                    l) {
                flattenJson(key2value, key, n);
            }
        } else {
            ArrayList<String> content = key2value.getOrDefault(key, new ArrayList<String>());

            if (content.isEmpty()) {
                key2value.put(key, content);
            }


            if (value == null)
                return;

            content.add(value.toString());
        }
    }

    static public HashMap<String, String> denormalize(JSONObject object, Map<String, List<Filter>> field2filter) {
        HashMap<String, ArrayList<String>> key2value = new HashMap<>();
        flattenJson(key2value, "", object);
        HashMap<String, String> l = new HashMap<>();

        String fieldName;
        ArrayList<String> values;

        for (Map.Entry<String, ArrayList<String>> entry : key2value.entrySet()) {
            fieldName = entry.getKey();
            values = entry.getValue();
            List<Filter> filters = field2filter.get(fieldName);

            if (filters != null) {
                for (int i = 0; i < values.size(); i++) {
                    for (Filter filter :
                            filters) {
                        values.set(i, filter.filter(values.get(i)));
                    }
                }
            }

            values.removeIf(n -> n == null);
            l.put(entry.getKey(), StringUtils.join(values, ' '));
        }

        return l;
    }
}
