import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;

public class ReportFilter {
    class Triple {
        Long reportId;
        Long creationDate;
        Long bucketId;

        public Triple(Long reportId, Long creationDate, Long bucketId) {
            this.reportId = reportId;
            this.creationDate = creationDate;
            this.bucketId = bucketId;
        }
    }

    private Integer window;
    private LinkedList<Triple> tuples;
    private HashMap<Long, Long> creationDateByBucket;

    public ReportFilter(Integer window) {
        this.window = window;
        this.tuples = new LinkedList<>();
        this.creationDateByBucket = new HashMap<>();
    }

    public void add(Report r) {
        Long bug_id = r.getId();
        Long bucketId = r.getDupId();
        Long creation_time = r.getCreationDate();

        if (bucketId == null)
            bucketId = bug_id;

        this.tuples.add(new Triple(bug_id, creation_time, bucketId));

        Long bucketCreationTime = this.creationDateByBucket.getOrDefault(bucketId, -1L);
        Long creationTimeDay = creation_time / (24 * 60 * 60);

//       Newest report in bucket
        if (bucketCreationTime < creationTimeDay)
            this.creationDateByBucket.put(bucketId, creationTimeDay);

    }

    public List getCandidates(Report r) {
        Long queryId = r.getId();
        Long qCreationTime = r.getCreationDate();
        Long qCreationTimeDay = r.getCreationDate() / (24 * 60 * 60);

        ArrayList<Long> l = new ArrayList<>();

        Long bucketCreationDt;
        for (Triple candidate :
                this.tuples) {
            bucketCreationDt = this.creationDateByBucket.get(candidate.bucketId);

            if (candidate.reportId == queryId){
                continue;
            }

            if (candidate.creationDate > qCreationTime || (candidate.creationDate.equals(qCreationTime)  && candidate.reportId > queryId))
                continue;

            if (0 < this.window && window < (qCreationTimeDay - bucketCreationDt))
                continue;

            l.add(candidate.reportId);
        }

//        System.out.println();
//        Collections.sort(l);
//        System.out.println(l.toString());

        return l;
    }
}
