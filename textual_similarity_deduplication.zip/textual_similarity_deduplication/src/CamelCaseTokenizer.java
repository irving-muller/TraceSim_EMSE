public class CamelCaseTokenizer {


}
