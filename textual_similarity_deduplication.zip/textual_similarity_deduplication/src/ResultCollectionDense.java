import org.apache.lucene.index.DirectoryReader;
import org.apache.lucene.search.ScoreDoc;
import org.apache.lucene.search.TopDocs;
import org.json.simple.JSONArray;

import java.io.*;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;

public class ResultCollectionDense implements ResultCollection {
    private DataOutputStream outputStream;

    public ResultCollectionDense(String path, int numQueries) throws IOException {
        File f = new File(path);
        f.createNewFile();
        this.outputStream = new DataOutputStream(new FileOutputStream(f));
        this.outputStream.writeLong(numQueries);
    }

    public void add(long queryId, TopDocs docs, DirectoryReader directoryReader, HashSet<Long> candidateSet) throws IOException {
        this.outputStream.writeLong(queryId);

//        System.out.print(String.format("%d ", queryId));
        if (docs != null) {
            Long candId;
            List<Tuple> reports = new LinkedList<>();

            for (ScoreDoc scoreDoc :
                    docs.scoreDocs) {
                candId= Long.parseLong(directoryReader.document(scoreDoc.doc).getField("bug_id").stringValue());

                if (!candidateSet.contains(candId)) {
                    continue;
                }

                reports.add(new Tuple(candId, (double) scoreDoc.score));
            }

            this.outputStream.writeLong(reports.size());

            for (Tuple t:
                 reports) {
                this.outputStream.writeLong(t.repId);
                this.outputStream.writeDouble(t.score);
            }

        }else {
            this.outputStream.writeLong(0);
        }
    }

    public void close() throws IOException {
        this.outputStream.close();
    }
}
