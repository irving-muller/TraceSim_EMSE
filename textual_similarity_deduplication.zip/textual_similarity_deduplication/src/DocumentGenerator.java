import org.apache.lucene.document.*;
import org.apache.lucene.search.BooleanClause;
import org.json.simple.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class DocumentGenerator {
    private List<Pattern> blackListFields;
    private List<Pattern> noIndexFields;
    private List<Pattern> whiteListFields;
    private List<Pattern> noParseFields;

    public DocumentGenerator(List<String> blackList, List<String> noIndex, List<String> whiteList , List<String> noParseList) {
        this.blackListFields = new ArrayList<>();
        this.noIndexFields = new ArrayList<>();
        this.whiteListFields = new ArrayList<>();
        this.noParseFields = new ArrayList<>();

        for (String f:
                blackList) {
            blackListFields.add(Pattern.compile(f, Pattern.CASE_INSENSITIVE));
        }

        for (String f:
                noIndex) {
            noIndexFields.add(Pattern.compile(f, Pattern.CASE_INSENSITIVE));
        }

        for (String f:
                whiteList) {
            whiteListFields.add(Pattern.compile(f, Pattern.CASE_INSENSITIVE));
        }

        for (String f:
                noParseList) {
            noParseFields.add(Pattern.compile(f, Pattern.CASE_INSENSITIVE));
        }
    }

//    public DocumentGenerator(List<Pattern> blackListFields, List<Pattern> noIndexFields, List<Pattern> keepFields) {
//        this.blackListFields = blackListFields;
//        this.noIndexFields = noIndexFields;
//        this.keepFields = keepFields;
//    }

    private boolean match(List<Pattern> patterns, String str){
        for (Pattern p :
                patterns) {
            Matcher m = p.matcher(str);

            if(m.matches())
                return true;
        }

        return false;
    }

    public Document generateAndUpdate(Report report) {
        Document report_doc = new Document();

        String name, content;
        for (
                Map.Entry<String, String> entry :
                report.getNameContent()) {
            name = entry.getKey();
            content = entry.getValue();

            if(this.whiteListFields.size() > 1 && !this.match(this.whiteListFields, name))
                continue;

            if (this.match(this.blackListFields, name))
                continue;

            Class c;
            if (this.match(this.noIndexFields, name)) {
                report_doc.add(new StoredField(name, content));
                c = StoredField.class;
            } else if(this.match(this.noParseFields, name)) {
                report_doc.add(new StringField(name, content, Field.Store.NO));
                c = StringField.class;
            }else {
                report_doc.add(new TextField(name, content, Field.Store.NO));
                c = TextField.class;
            }
            report.addIndexType(name, c);
        }

        return report_doc;
    }
}
